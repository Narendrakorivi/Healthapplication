package in.nareshit.raghu.constants;

public enum UserRoles {
	
	PATIENT, ADMIN, DOCTOR ;

}
