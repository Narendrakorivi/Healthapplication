package in.nareshit.raghu.constants;

public enum SlotStatus {
	
	PENDING, ACCEPTED, REJECTED, CANCELLED
	
}
